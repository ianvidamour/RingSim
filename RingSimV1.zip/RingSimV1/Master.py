import pickle
import numpy as np
import graphics as gp
import matplotlib.pyplot as plt

class RingSim(object):    
    # Initialise array with given parameters    
    def __init__(self, RingNum, BaseE0=1.575e-19, H0=145, alpha=1.5, Tau0=1e-10, kT=1.38e-23*293, RingSize=16, PinCoupling=0.75, Frequency=0.2, HDist=20, EDist=1e-21, FieldEccentricity=0):
        # Define how many regions each ring is split up into
        self.RingSize = RingSize
        self.Eccentricity = FieldEccentricity
        # Define how many rings make up the array
        self.RingNum = RingNum
        self.alpha = alpha
        self.kT = kT
        # Calculate real time between discrete 'ticks' of system
        self.TickTime = 1 / (Frequency * RingSize)
        self.time = 0
        # Create empty variables for later assignment
        Array=[]
        E0=[]
        # Set probability of a Domain Wall pinning at each junction
        self.BaseE0 = BaseE0
        self.Tau0 = Tau0
        self.PinCoupling = PinCoupling
        # Set row size for the organisation of the rings, current form only supports square arrays
        self.RowSize = int(np.sqrt(RingNum))
        self.K = (RingSize/2)
        # Initialise the rings in the array to have a pair of domain walls, and sets the 
        # E0 probability at the junction locations.
        Direction = []
        Magnetisation = []
        Mx = []
        My = []
        self.H0 = H0
        H_switching=[]
        # Saturates the array
        for r in range(RingNum):
            Ring=[]
            Dir=[]
            Mag=[]
            #Sets Hsw for each ring, with normally distributed noise representing 'manufacturing' error
            H_switching.append(np.random.normal(H0, HDist))
            for i in range(RingSize):
                #Initialises DWs for full onion state in line with saturating field
                if i==RingSize/4 or i==3*RingSize/4:
                    # Adds DWs to 
                    Ring.append(1)
                    Mag.append(0)
                    if sum(Dir)==0:
                        # Defines DW at bottom of rings as H2H
                        Dir.append(1)
                    else:
                        # Defines DW at top of rings as T2T
                        Dir.append(sum(Dir)*-1)
                else: 
                    Ring.append(0)
                    Dir.append(0)
                    Mag.append(0)
            Mx.append(0)
            My.append(0)
            Array.append(Ring)
            Direction.append(Dir)
            Magnetisation.append(Mag)
            Pin = []
            #Sets E0 for each junction site
            for i in range(RingSize):
                # Adds 'manufacturing defects' with random noise
                if i==0 or i==RingSize/2 or i==RingSize/4 or i==3*RingSize/4:
                    Pin.append(np.random.normal(BaseE0, EDist))
                else: 
                    Pin.append(0)
            E0.append(Pin)
            pin = E0[r]
            #Removes pinning conditions for perimeter rings
            if r//self.RowSize==0:
                pin[int(3*RingSize/4)] = 0
                E0[r] = pin
            if r%self.RowSize==0:
                pin[int(RingSize/2)] = 0
                E0[r] = pin
            if r%self.RowSize==self.RowSize-1:
                pin[0] = 0
                E0[r] = pin
            if r//self.RowSize==self.RowSize-1:
                pin[int(RingSize/4)] = 0
                E0[r] = pin
            # Defines tangential direction of magnetisation for non-DW elements in the ring based on DW structure
            mag = Magnetisation[r]
            direction = Direction[r]
            MagDir = 1
            for y in range(self.RingSize):
                if direction[y] == -1:
                    T2TLoc = y 
            for x in range(self.RingSize):
                if direction[(T2TLoc + x) % self.RingSize] == 0:
                    mag[(T2TLoc + x) % self.RingSize] = MagDir
                elif direction[(T2TLoc + x) % self.RingSize] == 1:
                    MagDir = - 1                
            Magnetisation[r] = mag
            Direction[r] = direction
            mx = []
            my = []
            #Calculates components from magnetisation direction in x and y direction
            for i in range(RingSize):
                mx.append(np.sin((16-i) * 2 * np.pi/16) * mag[i])
                my.append(-np.cos((16-i) * 2 * np.pi/16) * mag[i])
            Mx[r] = sum(mx)
            My[r] = sum(my)
        #Calculates saturation magnetisation of array
        self.MaxM = sum(My)
        self.Array = Array
        self.E0 = E0
        self.Magnetisation = Magnetisation
        self.Direction = Direction
        self.H_switching = H_switching
        self.Mx = Mx
        self.My = My
        junction=[]
        #Defines junctions of array
        for i in range(2 * self.RowSize * (self.RowSize-1)):
            junction.append(0)
        self.junction = junction
        
    def nucleate(self, i, r):
        #Initialises a DW pair in an empty ring
        nucring = np.zeros(self.RingSize)
        nucdir = np.zeros(self.RingSize)
        newi = int((i+self.RingSize/2)%self.RingSize)
        locangle = newi * np.pi/8
        hangle = self.H2HMin * np.pi/8
        tangle = self.T2TMin * np.pi/8
        Lag1 = abs(hangle - locangle)
        if Lag1 > np.pi:
            Lag1 = 2 * np.pi - Lag1
        Lag2 = abs(tangle - locangle)
        if Lag2 > np.pi:
            Lag2 = 2 * np.pi - Lag2
        if Lag1 < 3 * np.pi/4:
            nucring[self.H2HMin] = 1
            nucdir[self.H2HMin] = 1
            if self.T2TMin==newi or self.T2TMin==newi:
                nucring[newi+1] = 1
                nucdir[newi+1] = -1
            else:
                nucring[newi] = 1
                nucdir[newi] = -1
        elif Lag2 < 3 * np.pi/4:
            nucring[self.T2TMin] = 1
            nucdir[self.T2TMin] = -1       
            if self.H2HMin==newi or self.T2TMin==newi:
                nucring[newi+1] = 1
                nucdir[newi+1] = 1
            else:
                nucring[newi] = 1
                nucdir[newi] = 1
        self.Array[r] = nucring
        self.Direction[r] = nucdir
        
    def defrust(self,i,r):
        #Nucleates a DW pair in a frustrated ring to alleviate frustration
        nucring = self.Array[r]
        nucdir = self.Direction[r]
        H = self.H2HMin
        T = self.T2TMin
        RowSize = self.RowSize
        for x in range(8):
            if nucring[(i+(x-4))%16] == 1:
                if (i+(x-4))%16 == 0:
                    if r % RowSize < RowSize-1:
                        loc=r//RowSize * (RowSize-1) + r%RowSize
                        self.junction[loc] += -1
                elif (i+(x-4))%16 == 4:
                    if r//RowSize<RowSize-1:
                        loc = RowSize * (RowSize-1) + (r//RowSize) * RowSize + r%RowSize
                        self.junction[loc] += -1
                elif (i+(x-4))%16 == 8:
                    if r%RowSize > 0:
                        loc = r//RowSize * (RowSize-1) + (r%RowSize)-1
                        self.junction[loc] += -1  
                elif (i+(x-4))%16 == 12:
                    if r//RowSize > 0:
                        loc = RowSize * (RowSize-1) + (r//RowSize) * RowSize - (RowSize-r%RowSize)
                        self.junction[loc] += -1                    
        if i == 0:
            if H < 4 or 12 < H < 16:
                for x in range(4):
                    nucring[x] = 0
                    nucring[x+12] = 0
                    nucdir[x] = 0
                    nucdir[x+12] = 0
                nucring[H] = 1
                nucdir[H] = 1
            elif T < 4 or 12 < T < 16:
                for x in range(4):
                    nucring[x] = 0
                    nucring[x+12] = 0
                    nucdir[x] = 0
                    nucdir[x+12] = 0
                nucring[T] = 1
                nucdir[T] = -1 
        else:
            if (i-4) < H < (i+4):
                for x in range(8):
                    nucring[i+(x-4)] = 0
                    nucdir[i+(x-4)] = 0
                nucring[H] = 1
                nucdir[H] = 1
            else:
                for x in range(8):
                    nucring[i+(x-4)] = 0
                    nucdir[i+(x-4)] = 0
                nucring[T] = 1
                nucdir[T] = -1
        if sum(nucring) % 2 == 1:
            nucring = np.zeros(16)
        self.Array[r] = nucring
        self.Direction[r] = nucdir

#Define how the ring responds to an incremental change in field direction             
    def tick(self,r):
        #Create a temporary vector for ring locations and E0 probabilities 
        #of ring to be operated on
        ring = self.Array[r]
        direction = self.Direction[r]
        e0 = self.E0[r]
        H_0 = self.H_switching[r]
        #Creates temporary empty vectors for tick function to fill
        tempring = np.zeros(self.RingSize)
        tempdir = np.zeros(self.RingSize)
        hmin = self.H2HMin
        tmin = self.T2TMin
        hangle = hmin*np.pi/8
        tangle = tmin*np.pi/8
        Tau0=self.Tau0
        RingSize = self.RingSize
        alpha = self.alpha
        kT = self.kT
        RowSize = self.RowSize
        junction = self.junction
        #Sets any rings with a single domain to annihilate (hard patch for error)
        if sum(ring) < 2:
            self.Array[r] = np.zeros(self.RingSize)
        for i in range(RingSize): 
            #Sets angle for location being iterated over
            locangle = i*np.pi/8
            DepinChance = 0
            Lag = 0
            #Performs tick operation on H2H DWs
            if ring[i]==1 and direction[i]==1:
                #Set lag between minimum energy point and location
                Lag = abs(hangle - locangle)
                if Lag > np.pi:
                    Lag = 2 * np.pi - Lag
                #Generate random variable for depin check
                x = np.random.ranf()
                #Calculate transverse component of field for reducing energy barrier
                FieldComponent = np.sin(Lag) * (np.sqrt((self.Hinput)**2 - ((self.Eccentricity * self.Hinput)**2) * np.sin(locangle)**2))
                #Calculate reduction in energy barrier via analytical approximation of Shorrock's equation
                DeltaH = e0[i] * (1 - (FieldComponent/H_0))**alpha
                #Calculate characteristic time of magnetisation reversel from Néel-Brown model
                Tau = Tau0 * np.exp(DeltaH/kT)
                #Calculate chance of depinning during discrete timestep
                DepinChance = 1-np.exp(-self.TickTime/Tau)
                #If DW is not located at a junction, skips depinning step and moves DW to minimum energy point
                if (i%(self.RingSize/4)) > 0 and Lag < np.pi/2:
                    tempring[i] = 0
                    tempdir[i] = 0
                    tempring[self.H2HMin] = 1
                    tempdir[self.H2HMin] += 1
                    if tempdir[self.H2HMin] == 0:
                        tempring[self.H2HMin] = 0
                elif i==0:
                    #locates the junction between position 0 of this ring and position 8 of the ring to the right
                    loc=r//self.RowSize * (self.RowSize-1) + r%self.RowSize
                    #Adds incoming DW to junction
                    if r%self.RowSize < self.RowSize-1:
                        if junction[loc]==1:
                            junction[loc] = 2
                        elif junction[loc]==0:
                            junction[loc] = 1
                        #If DWs are sharing a junction, alters pinning characteristics of junction
                        if junction[loc]==2:
                            DepinChance = DepinChance / self.PinCoupling                        
                    #If DW depins and DW doesn't have to pass a junction, moves to minimum energy point
                    if DepinChance > x and (self.H2HMin > ((3*self.RingSize/4) - 1) or self.H2HMin < (self.RingSize/4 + 1)):
                        tempring[i] = 0
                        tempdir[i] = 0
                        tempring[self.H2HMin] = 1
                        tempdir[self.H2HMin] += 1
                        if tempdir[self.H2HMin] == 0:
                            tempring[self.H2HMin] = 0
                        #If DWs were sharing a junction, depinning of first DW triggers the second to depin
                        if r%self.RowSize < self.RowSize-1:
                            if junction[loc] == 2:
                                junction[loc] = 3
                            elif junction[loc]==1:
                                junction[loc] = 0
                        #If adjacent ring was empty, nucleates a DW pair in it
                        if r%self.RowSize < self.RowSize-1 and sum(self.Array[r+1]) < 2: 
                            self.nucleate(i, r+1)
                        #If DW movement causes magnetic frustration, nucleates a pair of DWs in frustrated ring 
                        elif r%self.RowSize < self.RowSize-1 and sum(self.Array[r+1]) == 2:
                            selfmag = self.Magnetisation[r]
                            adjmag = self.Magnetisation[r+1]
                            if selfmag[0] == adjmag[int(self.RingSize/2)]:
                                self.defrust(int(self.RingSize/2), r+1)
                    #If minimum energy point was beyond another junction, checks if can also pass that junction
                    elif DepinChance > x and self.RingSize/4 < self.H2HMin < 3*self.RingSize/4:
                        #Changes junction properties to reflect DW depinning
                        if junction[loc]==2:
                            junction[loc] = 3
                        elif junction[loc]==1:
                            junction[loc] = 0
                        y = np.random.ranf()
                        FieldComponent = np.sin(Lag) * (np.sqrt((self.Hinput)**2 - ((self.Eccentricity * self.Hinput)**2) * np.sin(locangle)**2))
                        if (self.RingSize/2) < self.H2HMin < (3*self.RingSize/4):
                            ex = e0[int(3*self.RingSize/4)]
                        else:
                            ex = e0[int(self.RingSize/4)]      
                        DeltaH = ex * (1-(FieldComponent/H_0))**alpha
                        Tau = self.Tau0 * np.exp(DeltaH/kT)
                        DepinChance = 1-np.exp(-self.TickTime/Tau)
                        loc = self.RowSize * (self.RowSize-1) + (r//self.RowSize) * self.RowSize - (self.RowSize - r%self.RowSize)
                        #If DW passes location 12, ensures any pinned DWs at that junction depin, nucleates in any empty rings.
                        if DepinChance > y and (self.RingSize/2) < self.H2HMin < (3*self.RingSize/4):
                            tempring[i] = 0
                            tempdir[i] = 0
                            tempring[self.H2HMin] = 1
                            tempdir[self.H2HMin] += 1
                            if tempdir[self.H2HMin] == 0:
                                tempring[self.H2HMin] = 0
                            loc = self.RowSize * (self.RowSize-1) + (r//self.RowSize) * self.RowSize - (self.RowSize - r%self.RowSize)
                            if r//self.RowSize > 0:
                                #If junction passed over has a DW in it, causes DW to depin
                                if junction[loc]==1:
                                    junction[loc] = 3
                            if r%self.RowSize < self.RowSize-1 and sum(self.Array[r+1]) < 2: 
                                self.nucleate(i, r+1)
                            elif r%self.RowSize < self.RowSize-1 and sum(self.Array[r+1]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r+1]
                                if selfmag[0] == adjmag[int(self.RingSize/2)]:
                                    self.defrust(int(self.RingSize/2), r+1)
                            elif r//self.RowSize>0 and sum(self.Array[r-self.RowSize]) < 2 and self.RingSize/2 < self.H2HMin < 3*self.RingSize/4:
                                self.nucleate(i, r-self.RowSize)
                                self.tick(r-self.RowSize)
                            elif r//self.RowSize>0 and sum(self.Array[r-self.RowSize]) == 2 and self.RingSize/2 < self.H2HMin < 3*self.RingSize/4:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r-self.RowSize]
                                if selfmag[int(3*self.RingSize/4)] == adjmag[int(self.RingSize/4)]:
                                    self.defrust(int(self.RingSize/4), r-self.RowSize)
                                    self.tick(r-self.RowSize)
                        #As above but for location 4
                        elif DepinChance > y and self.RingSize/4 < self.H2HMin < self.RingSize/2:
                            tempring[i] = 0
                            tempdir[i] = 0
                            tempring[self.H2HMin] = 1
                            tempdir[self.H2HMin] += 1
                            if tempdir[self.H2HMin] == 0:
                                tempring[self.H2HMin] = 0
                            loc = self.RowSize * (self.RowSize-1) + (r//self.RowSize) * self.RowSize + r%self.RowSize
                            if r//self.RowSize < RowSize-1:
                                if junction[loc]==1:
                                    junction[loc] = 3
                            if r%RowSize < RowSize-1 and sum(self.Array[r+1]) < 2: 
                                self.nucleate(i, r+1)
                            elif r%RowSize < RowSize-1 and sum(self.Array[r+1]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r+1]
                                if selfmag[0] == adjmag[int(self.RingSize/2)]:
                                    self.defrust(int(self.RingSize/2), r+1)
                            elif r//RowSize < RowSize-1 and sum(self.Array[r+RowSize]) < 2 and self.RingSize/4 < self.H2HMin < self.RingSize/2:
                                self.nucleate(i, r+RowSize)
                            elif r//RowSize < RowSize-1 and sum(self.Array[r+RowSize]) == 2 and self.RingSize/44 < self.H2HMin < self.RingSize/2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r+RowSize]
                                if selfmag[int(self.RingSize/4)] == adjmag[int(3*self.RingSize/4)]:
                                    self.defrust(int(3*self.RingSize/4), r+RowSize)
                        #If DW can't bypass second junction, ensures it ends up in correct location
                        else:
                            tempring[i] = 0
                            tempdir[i] = 0
                            if self.RingSize/2 < self.H2HMin < 3*self.RingSize/4:
                                tempring[int(3*self.RingSize/4)] = 1
                                tempdir[int(3*self.RingSize/4)] += 1
                                if tempdir[int(3*self.RingSize/4)] == 0:
                                    tempring[int(3*self.RingSize/4)] = 0
                            else:
                                tempring[int(self.RingSize/4)] = 1
                                tempdir[int(self.RingSize/4)] += 1
                                if tempdir[int(self.RingSize/4)] == 0:
                                    tempring[int(self.RingSize/4)] = 0
                            if r%RowSize < RowSize-1 and sum(self.Array[r+1]) < 2: 
                                self.nucleate(i, r+1)
                            elif r%RowSize < RowSize-1 and sum(self.Array[r+1]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r+1]
                                if selfmag[0] == adjmag[int(self.RingSize/2)]:
                                    self.defrust(int(self.RingSize/2), r+1)
                    #If DW remains pinned, updates temporary vectors
                    else:
                        tempring[i] = ring[i]
                        tempdir[i] = direction[i]
                        if r%RowSize < RowSize-1:
                            if junction[loc]==2:
                                junction[loc] = 4
                #Repeat process for location 4
                elif i==RingSize/4:
                    loc = RowSize * (RowSize-1) + (r//RowSize) * RowSize + r%RowSize
                    if r//RowSize<RowSize-1:
                        if junction[loc]==1:
                            junction[loc] = 2
                        elif junction[loc]==0:
                            junction[loc] = 1
                        if junction[loc]==2:
                            DepinChance = DepinChance / self.PinCoupling
                    if DepinChance > x and self.H2HMin < self.RingSize/2 + 1:
                        tempring[i] = 0
                        tempdir[i] = 0
                        tempring[self.H2HMin] = 1
                        tempdir[self.H2HMin] += 1
                        if tempdir[self.H2HMin] == 0:
                            tempring[self.H2HMin] = 0
                        if r//RowSize < RowSize-1 and junction[loc]==2:                                
                            junction[loc] = 3
                        if r//RowSize<RowSize-1 and sum(self.Array[r+RowSize]) < 2:
                            self.nucleate(i, r+RowSize)
                        elif r//RowSize<RowSize-1 and sum(self.Array[r+RowSize]) == 2:
                            selfmag = self.Magnetisation[r]
                            adjmag = self.Magnetisation[r+RowSize]
                            if selfmag[int(self.RingSize/4)] == adjmag[int(3*self.RingSize/4)]:
                                self.defrust(int(3*self.RingSize/4), r+RowSize)
                    elif DepinChance > x and self.H2HMin > self.RingSize/2:
                        if r//RowSize < RowSize-1 and junction[loc]==2:                                
                            junction[loc] = 3
                        y = np.random.ranf()
                        FieldComponent = np.sin(Lag) * (np.sqrt((self.Hinput)**2 - ((self.Eccentricity * self.Hinput)**2) * np.sin(locangle)**2))
                        if self.H2HMin > 3*self.RingSize/4:
                            ex = e0[0]
                        else:
                            ex = e0[int(self.RingSize/2)]
                        DeltaH = ex * (1-(FieldComponent/H_0))**alpha
                        Tau = Tau0*np.exp(DeltaH/kT)
                        DepinChance=1-np.exp(-self.TickTime/Tau)
                        if DepinChance > y and self.H2HMin > 3*self.RingSize/4:
                            tempring[i] = 0
                            tempdir[i] = 0
                            tempring[self.H2HMin] = 1
                            tempdir[self.H2HMin] += 1
                            if tempdir[self.H2HMin] == 0:
                                tempring[self.H2HMin] = 0
                            loc = r//RowSize * (RowSize-1) + r%RowSize
                            if r%RowSize < RowSize-1:
                                if junction[loc]==1:
                                    junction[loc] = 3
                            if r//RowSize < RowSize-1 and sum(self.Array[r+RowSize]) < 2:
                                self.nucleate(i, r+RowSize)
                            elif r//RowSize < RowSize-1 and sum(self.Array[r+RowSize]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r+RowSize]
                                if selfmag[int(self.RingSize/4)] == adjmag[int(3*self.RingSize/4)]:
                                    self.defrust(12, r+RowSize)
                            elif r%RowSize < RowSize-1 and sum(self.Array[r+1]) < 2: 
                                self.nucleate(i, r+1)
                            elif r%RowSize < RowSize-1 and sum(self.Array[r+1]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r+1]
                                if selfmag[0] == adjmag[int(self.RingSize/2)]:
                                    self.defrust(int(self.RingSize/2), r+1)
                        elif DepinChance > y and self.RingSize/2 < self.H2HMin < 3*self.RingSize/4:
                            tempring[i] = 0
                            tempdir[i] = 0
                            tempring[self.H2HMin] = 1
                            tempdir[self.H2HMin] += 1
                            if tempdir[self.H2HMin] ==0:
                                tempring[self.H2HMin] = 0
                            loc = r//RowSize * (RowSize-1) + (r%RowSize)-1
                            if r%RowSize > 0:
                                if junction[loc]==1:
                                    junction[loc] = 3
                            if r//RowSize < RowSize-1 and sum(self.Array[r+RowSize]) < 2:
                                self.nucleate(i, r+RowSize)
                            elif r//RowSize < RowSize-1 and sum(self.Array[r+RowSize]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r+RowSize]
                                if selfmag[int(self.RingSize/4)] == adjmag[int(3*self.RingSize/4)]:
                                    self.defrust(int(3*self.RingSize/4), r+RowSize)
                            elif r%RowSize > 0 and sum(self.Array[r-1]) < 2:
                                self.nucleate(i, r-1)
                                self.tick(r-1)
                            elif r%RowSize > 0 and sum(self.Array[r-1]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r-1]
                                if selfmag[int(self.RingSize/2)] == adjmag[0]:
                                    self.defrust(0, r-1)
                                    self.tick(r-1)
                        else:
                            tempring[i] = 0
                            tempdir[i] = 0
                            if self.H2HMin > 3*self.RingSize/4:
                                tempring[0] = 1
                                tempdir[0] += 1
                                if tempdir[0] == 0:
                                    tempring[0] = 0
                            else:
                                tempring[int(self.RingSize/2)] = 1
                                tempdir[int(self.RingSize/2)] += 1
                                if tempdir[int(self.RingSize/2)] == 0:
                                    tempring[int(self.RingSize/2)] = 0
                            if r//RowSize < RowSize-1 and sum(self.Array[r+RowSize]) < 2:
                                self.nucleate(i, r+RowSize)
                            elif r//RowSize < RowSize-1 and sum(self.Array[r+RowSize]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r+RowSize]
                                if selfmag[int(self.RingSize/4)] == adjmag[int(3*self.RingSize/4)]:
                                    self.defrust(int(3*self.RingSize/4), r+RowSize)
                    else:
                        tempring[i] = 1
                        tempdir[i] = 1
                        if r//RowSize < RowSize-1:
                            if junction[loc]==2:   
                                junction[loc] = 4
                elif i==RingSize/2:
                    loc = r//RowSize * (RowSize-1) + (r%RowSize)-1
                    if r%RowSize > 0:
                        if junction[loc] == 0:
                            junction[loc] = 1
                        elif junction[loc]==3:
                            DepinChance = 1
                            junction[loc] = 0
                        elif junction[loc]==4:
                            DepinChance = 0
                            junction[loc]=2
                    if DepinChance > x and ((self.RingSize/4 - 1) < self.H2HMin < (3*self.RingSize/4 + 1)):
                        tempring[i] = 0
                        tempdir[i] = 0
                        tempring[self.H2HMin] = 1
                        tempdir[self.H2HMin] += 1
                        if tempdir[self.H2HMin] == 0:
                            tempring[self.H2HMin] = 0                                                   
                        if r%RowSize > 0 and sum(self.Array[r-1]) < 2:
                            self.nucleate(i, r-1)
                            self.tick(r-1)
                        elif r%RowSize > 0 and sum(self.Array[r-1]) == 2:
                            selfmag = self.Magnetisation[r]
                            adjmag = self.Magnetisation[r-1]
                            if selfmag[int(self.RingSize/2)] == adjmag[0]:
                                self.defrust(0, r-1)
                                self.tick(r-1)
                    elif DepinChance > x and ((self.H2HMin < self.RingSize/4) or (self.H2HMin > 3*self.RingSize/4)):
                        y = np.random.ranf()
                        FieldComponent = np.sin(Lag) * (np.sqrt((self.Hinput)**2 - ((self.Eccentricity * self.Hinput)**2) * np.sin(locangle)**2))
                        if self.H2HMin < self.RingSize/4:
                            ex = e0[int(self.RingSize/4)]
                        else:
                            ex = e0[int(3*self.RingSize/4)]
                        DeltaH = ex*(1-(FieldComponent/H_0))**alpha
                        Tau = Tau0*np.exp(DeltaH/kT)
                        DepinChance = 1-np.exp(-self.TickTime/Tau)
                        if DepinChance > y and self.H2HMin < self.RingSize/4:
                            tempring[i] = 0
                            tempdir[i] = 0
                            tempring[self.H2HMin] = 1
                            tempdir[self.H2HMin] += 1
                            if tempdir[self.H2HMin] == 0:
                                tempring[self.H2HMin] = 0
                            loc = RowSize * (RowSize-1) + (r//RowSize) * RowSize + r%RowSize
                            if r//RowSize < RowSize-1:
                                if junction[loc]==1:
                                    junction[loc] = 3
                            if r%RowSize > 0 and sum(self.Array[r-1]) < 2:
                                self.nucleate(i, r-1)
                                self.tick(r-1)
                            elif r%RowSize > 0 and sum(self.Array[r-1]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r-1]
                                if selfmag[int(self.RingSize/2)] == adjmag[0]:
                                    self.defrust(0, r-1)
                                    self.tick(r-1)
                            elif r//RowSize < RowSize-1 and sum(self.Array[r+RowSize]) < 2:
                                self.nucleate(i, r+RowSize)
                            elif r//RowSize < RowSize-1 and sum(self.Array[r+RowSize]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r+RowSize]
                                if selfmag[int(self.RingSize/4)] == adjmag[int(3*self.RingSize/4)]:
                                    self.defrust(int(3*self.RingSize/4), r+RowSize)
                        elif DepinChance > y and self.H2HMin > 3*self.RingSize/4:
                            tempring[i] = 0
                            tempdir[i] = 0
                            tempring[self.H2HMin] = 1
                            tempdir[self.H2HMin] += 1
                            if tempdir[self.H2HMin] == 0:
                                tempring[self.H2HMin] = 0
                            loc = RowSize * (RowSize-1) + (r//RowSize) * RowSize - (RowSize - r%RowSize)
                            if r//RowSize > 0:
                                if junction[loc]==1:
                                    junction[loc] = 3
                            if r%RowSize > 0 and sum(self.Array[r-1]) < 2:
                                self.nucleate(i, r-1)
                                self.tick(r-1)
                            elif r%RowSize > 0 and sum(self.Array[r-1]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r-1]
                                if selfmag[int(self.RingSize/2)] == adjmag[0]:
                                    self.defrust(0, r-1)
                                    self.tick(r-1)
                            elif r//RowSize > 0 and sum(self.Array[r-RowSize]) < 2:
                                self.nucleate(i, r-RowSize)
                                self.tick(r-RowSize)
                            elif r//RowSize > 0 and sum(self.Array[r-RowSize]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r-RowSize]
                                if selfmag[int(3*self.RingSize/4)] == adjmag[int(self.RingSize/4)]:
                                    self.defrust(int(self.RingSize/4), r-RowSize)
                        else:
                            tempring[i] = 0
                            tempdir[i] = 0
                            if self.H2HMin < int(self.RingSize/4):
                                tempring[int(self.RingSize/4)] = 1
                                tempdir[int(self.RingSize/4)] += 1
                                if tempdir[int(self.RingSize/4)] == 0:
                                    tempring[int(self.RingSize/4)] = 0
                            else:
                                tempring[int(3*self.RingSize/4)] = 1
                                tempdir[int(3*self.RingSize/4)] += 1
                                if tempdir[int(3*self.RingSize/4)] == 0:
                                    tempring[int(3*self.RingSize/4)] = 0
                            if r%RowSize > 0 and sum(self.Array[r-1]) < 2:
                                self.nucleate(i, r-1)
                                self.tick(r-1)
                            elif r%RowSize > 0 and sum(self.Array[r-1]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r-1]
                                if selfmag[int(self.RingSize/2)] == adjmag[0]:
                                    self.defrust(0, r-1)
                                    self.tick(r-1)
                    else:
                        tempring[i] = ring[i]
                        tempdir[i] = direction[i]                       
                elif i == 3 * RingSize / 4:
                    loc = RowSize * (RowSize-1) + (r//RowSize) * RowSize - (RowSize-r%RowSize)
                    if r//RowSize > 0:
                        if junction[loc]==3:
                            DepinChance = 1
                            junction[loc]=0
                        elif junction[loc]==4:
                            DepinChance = 0
                            junction[loc] = 2
                        elif junction[loc]==1:
                            junction[loc] = 2
                    if DepinChance > x and ((self.H2HMin > (self.RingSize/2 - 1)) or self.H2HMin==0): 
                        tempring[i] = 0
                        tempdir[i] = 0
                        tempring[self.H2HMin] = 1
                        tempdir[self.H2HMin] += 1    
                        if tempdir[self.H2HMin] == 0:
                            tempring[self.H2HMin] = 0
                        if r//RowSize > 0 and sum(self.Array[r-RowSize]) < 2:
                            self.nucleate(i, r-RowSize)
                            self.tick(r-RowSize)
                        elif r//RowSize > 0 and sum(self.Array[r-RowSize]) == 2:
                            selfmag = self.Magnetisation[r]
                            adjmag = self.Magnetisation[r-RowSize]
                            if selfmag[int(3*self.RingSize/4)] == adjmag[int(self.RingSize/4)]:
                                self.defrust(int(self.RingSize/4), r-RowSize)
                                self.tick(r-RowSize)
                    elif DepinChance > x and self.H2HMin < self.RingSize/2:
                        y = np.random.ranf()
                        FieldComponent = np.sin(Lag) * (np.sqrt((self.Hinput)**2 - ((self.Eccentricity * self.Hinput)**2) * np.sin(locangle)**2))
                        if self.RingSize/4 < self.H2HMin < self.RingSize/2:
                            ex = e0[int(self.RingSize/2)]
                        else:
                            ex = e0[0]
                        DeltaH = ex * (1-(FieldComponent/H_0))**alpha
                        Tau = Tau0 * np.exp(DeltaH/kT)
                        DepinChance = 1-np.exp(-self.TickTime/Tau)
                        if DepinChance > y and self.RingSize/4 < self.H2HMin < self.RingSize/2:
                            tempring[i] = 0
                            tempdir[i] = 0
                            tempring[self.H2HMin] = 1
                            tempdir[self.H2HMin] += 1
                            if tempdir[self.H2HMin] == 0:
                                tempring[self.H2HMin] = 0
                            loc = r//RowSize * (RowSize-1) + (r%RowSize)-1
                            if r%RowSize > 0:
                                if junction[loc]==1:
                                    junction[loc] = 3
                            if r//RowSize > 0 and sum(self.Array[r-RowSize]) < 2:
                                self.nucleate(i, r-RowSize)
                                self.tick(r-RowSize)
                            elif r//RowSize > 0 and sum(self.Array[r-RowSize]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r-RowSize]
                                if selfmag[int(3*self.RingSize/4)] == adjmag[int(self.RingSize/4)]:
                                    self.defrust(int(self.RingSize/4), r-RowSize)
                                    self.tick(r-RowSize)
                            elif r%RowSize > 0 and sum(self.Array[r-1]) < 2:
                                self.nucleate(i, r-1)
                                self.tick(r-1)
                            elif r%RowSize > 0 and sum(self.Array[r-1]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r-1]
                                if selfmag[int(self.RingSize/2)] == adjmag[0]:
                                    self.defrust(0, r-1)
                                    self.tick(r-1)
                        elif DepinChance > y and 0 < self.H2HMin < self.RingSize/4:
                            tempring[i] = 0
                            tempdir[i] = 0
                            tempring[self.H2HMin] = 1
                            tempdir[self.H2HMin] += 1
                            if tempdir[self.H2HMin] == 0:
                                tempring[self.H2HMin] = 0
                            loc = r//RowSize * (RowSize-1) + r%RowSize
                            if r%RowSize<RowSize-1:
                                if junction[loc]==1:
                                    junction[loc] = 3
                            if r//RowSize > 0 and sum(self.Array[r-RowSize]) < 2:
                                self.nucleate(i, r-RowSize)
                                self.tick(r-RowSize)
                            elif r//RowSize > 0 and sum(self.Array[r-RowSize]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r-RowSize]
                                if selfmag[int(3*self.RingSize/4)] == adjmag[int(self.RingSize/4)]:
                                    self.defrust(int(self.RingSize/4), r-RowSize)
                                    self.tick(r-RowSize)
                            elif r%RowSize < RowSize-1 and sum(self.Array[r+1]) < 2: 
                                self.nucleate(i, r+1)
                            elif r%RowSize < RowSize-1 and sum(self.Array[r+1]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r+1]
                                if selfmag[0] == adjmag[int(self.RingSize/2)]:
                                    self.defrust(int(self.RingSize/2), r+1)
                        else:
                            tempring[i] = 0
                            tempdir[i] = 0
                            if self.H2HMin > self.RingSize/4:
                                tempring[int(self.RingSize/2)] = 1
                                tempdir[int(self.RingSize/2)] += 1
                                if tempdir[int(self.RingSize/2)] == 0:
                                    tempring[int(self.RingSize/2)] = 0
                            else:
                                tempring[0] = 1
                                tempdir[0] += 1
                                if tempdir[0] == 0:
                                    tempring[0] = 0
                            if r//RowSize > 0 and sum(self.Array[r-RowSize]) < 2:
                                self.nucleate(i, r-RowSize)
                                self.tick(r-RowSize)
                            elif r//RowSize > 0 and sum(self.Array[r-RowSize]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r-RowSize]
                                if selfmag[int(3*self.RingSize/4)] == adjmag[int(self.RingSize/4)]:
                                    self.defrust(int(self.RingSize/4), r-RowSize)
                                    self.tick(r-RowSize)
                    else:
                        tempring[i] = ring[i]
                        tempdir[i] = direction[i]
            #Repeats entire process for T2T DWs
            if ring[i]==1 and direction[i]==-1:
                Lag=abs(tangle-locangle)
                if Lag > np.pi:
                    Lag= 2 * np.pi - Lag
                x = np.random.ranf()
                FieldComponent = np.sin(Lag) * (np.sqrt((self.Hinput)**2 - ((self.Eccentricity * self.Hinput)**2) * np.sin(locangle)**2))
                DeltaH = e0[i] * (1-(FieldComponent/H_0))**alpha
                Tau = Tau0 * np.exp(DeltaH/kT)
                DepinChance = 1-np.exp(-self.TickTime/Tau)
                if (i%4) > 0:
                    tempring[i] = 0
                    tempdir[i] = 0
                    tempring[self.T2TMin] = 1
                    tempdir[self.T2TMin] += -1
                    if tempdir[self.T2TMin] == 0:
                        tempring[self.T2TMin] = 0
                elif i==0:
                    #locates the junction between position 0 of this ring and position 8 of the ring to the right
                    loc = r//RowSize*(RowSize-1) + r%RowSize
                    if r%RowSize < RowSize-1:
                        if junction[loc]==1:
                            junction[loc] = 2
                        elif junction[loc]==0:
                            junction[loc] = 1
                        if junction[loc]==2:
                            DepinChance = DepinChance / self.PinCoupling
                    if DepinChance > x and ((self.T2TMin > 3*self.RingSize/4 - 1) or (self.T2TMin < self.RingSize/4 + 1)):
                        tempring[i] = 0
                        tempdir[i] = 0
                        tempring[self.T2TMin] = 1
                        tempdir[self.T2TMin] += -1
                        if tempdir[self.T2TMin] == 0:
                            tempring[self.T2TMin] = 0
                        if junction[loc]==2:
                            junction[loc] = 3
                        if r%RowSize < RowSize-1 and sum(self.Array[r+1]) < 2: 
                            self.nucleate(i, r+1)
                        elif r%RowSize < RowSize-1 and sum(self.Array[r+1]) == 2:
                            selfmag = self.Magnetisation[r]
                            adjmag = self.Magnetisation[r+1]
                            if selfmag[0] == adjmag[int(self.RingSize/2)]:
                                self.defrust(int(self.RingSize/2), r+1)
                    elif DepinChance > x and self.RingSize/4 < self.T2TMin < 3*self.RingSize/4:
                        y = np.random.ranf()
                        FieldComponent = np.sin(Lag) * (np.sqrt((self.Hinput)**2 - ((self.Eccentricity * self.Hinput)**2) * np.sin(locangle)**2))
                        if self.RingSize/2 < self.T2TMin < 3*self.RingSize/4:
                            ex = e0[int(3*self.RingSize/4)]
                        else:
                            ex = e0[int(self.RingSize/4)]
                        DeltaH = ex*(1-(FieldComponent/H_0))**alpha
                        Tau = Tau0*np.exp(DeltaH/kT)
                        DepinChance = 1 - np.exp(-self.TickTime/Tau)
                        if DepinChance > y and self.RingSize/2 < self.T2TMin < 3*self.RingSize/4:
                            tempring[i] = 0
                            tempdir[i] = 0
                            tempring[self.T2TMin] = 1
                            tempdir[self.T2TMin] += -1
                            if tempdir[self.T2TMin] == 0:
                                tempring[self.T2TMin] = 0
                            loc = RowSize*(RowSize-1) + (r//RowSize) * RowSize - (RowSize - r%RowSize)
                            if r//RowSize > 0:
                                if junction[loc]==1:
                                    junction[loc] = 3
                            if r%RowSize < RowSize-1 and sum(self.Array[r+1]) < 2: 
                                self.nucleate(i, r+1)
                            elif r%RowSize < RowSize-1 and sum(self.Array[r+1]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r+1]
                                if selfmag[0] == adjmag[int(self.RingSize/2)]:
                                    self.defrust(int(self.RingSize/2), r+1)
                            elif r//RowSize > 0 and sum(self.Array[r-RowSize]) < 2 and self.RingSize/2 < self.T2TMin < 3*self.RingSize/4:
                                self.nucleate(i, r-RowSize)
                                self.tick(r-RowSize)
                            elif r//RowSize > 0 and sum(self.Array[r-RowSize]) == 2 and self.RingSize/2 < self.T2TMin < 3*self.RingSize/4:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r-RowSize]
                                if selfmag[int(3*self.RingSize/4)] == adjmag[int(self.RingSize/4)]:
                                    self.defrust(int(self.RingSize/4), r-RowSize)
                                    self.tick(r-RowSize)
                        elif DepinChance > y and self.RingSize/4 < self.T2TMin < self.RingSize/2:
                            tempring[i] = 0
                            tempdir[i] = 0
                            tempring[self.T2TMin] = 1
                            tempdir[self.T2TMin] += -1
                            if tempdir[self.T2TMin] == 0:
                                tempring[self.T2TMin] = 0
                            loc = RowSize * (RowSize-1) + (r//RowSize) * RowSize + r%RowSize
                            if r//RowSize < RowSize-1:
                                if junction[loc]==1:
                                    junction[loc] = 3
                            if r%RowSize<RowSize-1 and sum(self.Array[r+1]) < 2: 
                                self.nucleate(i, r+1)
                            elif r%RowSize<RowSize-1 and sum(self.Array[r+1]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r+1]
                                if selfmag[0] == adjmag[int(self.RingSize/2)]:
                                    self.defrust(int(self.RingSize/2), r+1)  
                            elif r//RowSize<RowSize-1 and sum(self.Array[r+RowSize]) < 2 and self.RingSize/4 < self.T2TMin < self.RingSize/2:
                                self.nucleate(i, r+RowSize)
                            elif r//RowSize<RowSize-1 and sum(self.Array[r+RowSize]) == 2 and self.RingSize/4 < self.T2TMin < self.RingSize/2:    
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r+RowSize]
                                if selfmag[int(self.RingSize/4)] == adjmag[int(3*self.RingSize/4)]:
                                    self.defrust(int(3*self.RingSize/4), r+RowSize)
                        else:
                            tempring[i] = 0
                            tempdir[i] = 0
                            if self.RingSize/2 < self.T2TMin < 3*self.RingSize/4:
                                tempring[int(3*self.RingSize/4)] = 1
                                tempdir[int(3*self.RingSize/4)] += -1
                                if tempdir[int(3*self.RingSize/4)] == 0:
                                    tempring[int(3*self.RingSize/4)] = 0
                            else:
                                tempring[int(self.RingSize/4)] = 1
                                tempdir[int(self.RingSize/4)] += -1
                                if tempdir[int(self.RingSize/4)] == 0:
                                    tempring[int(self.RingSize/4)] =0
                            if r%RowSize < RowSize-1 and sum(self.Array[r+1]) < 2: 
                                self.nucleate(i, r+1)
                            elif r%RowSize < RowSize-1 and sum(self.Array[r+1]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r+1]
                                if selfmag[0] == adjmag[int(self.RingSize/2)]:
                                    self.defrust(int(self.RingSize/2), r+1)
                    else:
                        tempring[i] = ring[i]
                        tempdir[i] = direction[i]
                        if r%RowSize < RowSize-1:
                            if junction[loc]==2:
                                junction[loc] = 4
                elif i == self.RingSize/4:
                    loc = RowSize * (RowSize-1) + (r//RowSize) * RowSize + r%RowSize
                    if r//RowSize < RowSize-1:
                        if junction[loc]==1:
                            junction[loc] = 2
                        elif junction[loc]==0:
                            junction[loc] = 1
                        if junction[loc]==2:
                            DepinChance = DepinChance / self.PinCoupling
                    if DepinChance > x and self.T2TMin < (self.RingSize/2 + 1):
                        tempring[i] = 0
                        tempdir[i] = 0
                        tempring[self.T2TMin] = 1
                        tempdir[self.T2TMin] += -1
                        if tempdir[self.T2TMin] == 0:
                            tempring[self.T2TMin] = 0
                        if r//RowSize < RowSize-1:
                            if junction[loc]==2:
                                junction[loc] = 3
                        if r//RowSize < RowSize-1 and sum(self.Array[r+RowSize]) < 2:
                                self.nucleate(i, r+RowSize)
                        elif r//RowSize < RowSize-1 and sum(self.Array[r+RowSize]) == 2:
                            selfmag = self.Magnetisation[r]
                            adjmag = self.Magnetisation[r+RowSize]
                            if selfmag[int(self.RingSize/4)] == adjmag[int(3*self.RingSize/4)]:
                                self.defrust(int(3*self.RingSize/4), r+RowSize)
                    elif DepinChance > x and self.T2TMin > self.RingSize/2:
                        y=np.random.ranf()
                        FieldComponent = np.sin(Lag) * (np.sqrt((self.Hinput)**2 - ((self.Eccentricity * self.Hinput)**2) * np.sin(locangle)**2))
                        if self.T2TMin > 3*self.RingSize/4:
                            ex = e0[0]
                        else:
                            ex = e0[int(self.RingSize/2)]
                        DeltaH = ex * (1-(FieldComponent/H_0))**alpha
                        Tau = Tau0 * np.exp(DeltaH/kT)
                        DepinChance = 1 - np.exp(-self.TickTime/Tau)
                        if DepinChance > y and self.T2TMin > 3*self.RingSize/4:
                            tempring[i] = 0
                            tempdir[i] = 0
                            tempring[self.T2TMin] = 1
                            tempdir[self.T2TMin] += -1
                            if tempdir[self.T2TMin] == 0:
                                tempring[self.T2TMin] = 0
                            loc = r//RowSize * (RowSize-1) + r%RowSize
                            if r%RowSize < RowSize-1:
                                if junction[loc]==1:
                                    junction[loc] = 3
                            if r//RowSize < RowSize-1 and sum(self.Array[r+RowSize]) < 2:
                                self.nucleate(i, r+RowSize)
                            elif r//RowSize < RowSize-1 and sum(self.Array[r+RowSize]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r+RowSize]
                                if selfmag[int(self.RingSize/4)] == adjmag[int(3*self.RingSize/4)]:
                                    self.defrust(int(3*self.RingSize/4), r+RowSize)
                            elif r%RowSize < RowSize-1 and sum(self.Array[r+1]) < 2: 
                                self.nucleate(i, r+1)
                            elif r%RowSize < RowSize-1 and sum(self.Array[r+1]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r+1]
                                if selfmag[0] == adjmag[int(self.RingSize/2)]:
                                    self.defrust(int(self.RingSize/2), r+1)
                        elif DepinChance > y and self.RingSize/2 < self.T2TMin < 3*self.RingSize/4:
                            tempring[i] = 0
                            tempdir[i] = 0
                            tempring[self.T2TMin] = 1
                            tempdir[self.T2TMin] += -1
                            if tempdir[self.T2TMin] == 0:
                                tempring[self.T2TMin] = 0
                            loc = r//RowSize * (RowSize-1) + (r%RowSize)-1
                            if r%RowSize > 0:
                                if junction[loc]==1:
                                    junction[loc] = 3
                            if r//RowSize < RowSize-1 and sum(self.Array[r+RowSize]) < 2:
                                self.nucleate(i, r+RowSize)
                            elif r//RowSize < RowSize-1 and sum(self.Array[r+RowSize]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r+RowSize]
                                if selfmag[int(self.RingSize/4)] == adjmag[int(3*self.RingSize/4)]:
                                    self.defrust(int(3*self.RingSize/4), r+RowSize)
                            elif r%RowSize > 0 and sum(self.Array[r-1]) < 2:
                                self.nucleate(i, r-1)
                                self.tick(r-1)
                            elif r%RowSize > 0 and sum(self.Array[r-1]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r-1]
                                if selfmag[int(self.RingSize/2)] == adjmag[0]:
                                    self.defrust(0, r-1)
                                    self.tick(r-1)
                        else:
                            tempring[i] = 0
                            tempdir[i] = 0
                            if self.T2TMin > 3*self.RingSize/4:
                                tempring[0] = 1
                                tempdir[0] += -1
                                if tempdir[0] == 0:
                                    tempring[0] = 0
                            else:
                                tempring[int(self.RingSize/2)] = 1
                                tempdir[int(self.RingSize/2)] += -1
                                if tempdir[int(self.RingSize/2)] ==0:
                                    tempring[int(self.RingSize/2)] = 0
                            if r//RowSize<RowSize-1 and sum(self.Array[r+RowSize]) < 2:
                                self.nucleate(i, r+RowSize)
                            elif r//RowSize<RowSize-1 and sum(self.Array[r+RowSize]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r+RowSize]
                                if selfmag[int(self.RingSize/4)] == adjmag[int(3*self.RingSize/4)]:
                                    self.defrust(int(3*self.RingSize/4), r+RowSize)
                    else:
                        tempring[i] = 1
                        tempdir[i] = -1
                        if r//RowSize < RowSize-1:
                            if junction[loc]==2:
                                junction[loc] = 4
                elif i==RingSize/2:
                    loc = r//RowSize * (RowSize-1) + (r%RowSize)-1
                    if r%RowSize > 0:
                        if junction[loc]==3:
                            DepinChance = 1
                            junction[loc] = 0
                        elif junction[loc]==4:
                            DepinChance = 0
                            junction[loc] = 2
                        elif junction[loc]==1:
                            junction[loc] = 2
                    if DepinChance > x and self.RingSize/4 - 1 < self.T2TMin < 3*self.RingSize/4 + 1:
                        tempring[i] = 0
                        tempdir[i] = 0
                        tempring[self.T2TMin] = 1
                        tempdir[self.T2TMin] += -1
                        if tempdir[self.T2TMin] == 0:
                            tempring[self.T2TMin] = 0                            
                        if r%RowSize > 0 and sum(self.Array[r-1]) < 2:
                            self.nucleate(i, r-1)
                            self.tick(r-1)
                        elif r%RowSize > 0 and sum(self.Array[r-1]) == 2:
                            selfmag = self.Magnetisation[r]
                            adjmag = self.Magnetisation[r-1]
                            if selfmag[int(self.RingSize/4)] == adjmag[0]:
                                self.defrust(0, r-1)
                                self.tick(r-1)
                    elif DepinChance > x and (self.T2TMin < self.RingSize/4 or self.T2TMin > 3*self.RingSize/4):
                        y = np.random.ranf()
                        FieldComponent = np.sin(Lag) * (np.sqrt((self.Hinput)**2 - ((self.Eccentricity * self.Hinput)**2) * np.sin(locangle)**2))
                        if self.T2TMin < 4:
                            ex = e0[int(self.RingSize/4)]
                        else:
                            ex = e0[int(3*self.RingSize/4)]
                        DeltaH = ex * (1-(FieldComponent/H_0))**alpha
                        Tau = Tau0 * np.exp(DeltaH/kT)
                        DepinChance = 1 - np.exp(-self.TickTime/Tau)
                        if DepinChance > y and self.T2TMin < self.RingSize/4:
                            tempring[i] = 0
                            tempdir[i] = 0
                            tempring[self.T2TMin] = 1
                            tempdir[self.T2TMin] += -1
                            if tempdir[self.T2TMin] == 0:
                                tempring[self.T2TMin] = 0
                            loc = RowSize * (RowSize-1) + (r//RowSize) * RowSize + r%RowSize
                            if r//RowSize < RowSize-1:
                                if junction[loc]==1:
                                    junction[loc] = 3
                            if r%RowSize > 0 and sum(self.Array[r-1]) < 2:
                                self.nucleate(i, r-1)
                                self.tick(r-1)
                            elif r%RowSize > 0 and sum(self.Array[r-1]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r-1]
                                if selfmag[int(self.RingSize/2)] == adjmag[0]:
                                    self.defrust(0, r-1)
                                    self.tick(r-1)
                            elif r//RowSize < RowSize-1 and sum(self.Array[r+RowSize]) < 2:
                                self.nucleate(i, r+RowSize)
                            elif r//RowSize < RowSize-1 and sum(self.Array[r+RowSize]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r+RowSize]
                                if selfmag[int(self.RingSize/4)] == adjmag[int(3*self.RingSize/4)]:
                                    self.defrust(int(3*self.RingSize/4), r+RowSize)
                        elif DepinChance > y and self.T2TMin > 3*self.RingSize/4:
                            tempring[i] = 0
                            tempdir[i] = 0
                            tempring[self.T2TMin] = 1
                            tempdir[self.T2TMin] += -1
                            if tempdir[self.T2TMin] == 0:
                                tempring[self.T2TMin] = 0
                            loc = RowSize * (RowSize-1) + (r//RowSize) * RowSize - (RowSize-r%RowSize)
                            if junction[loc]==1:
                                junction[loc] = 3
                            if r%RowSize > 0 and sum(self.Array[r-1]) < 2:
                                self.nucleate(i, r-1)
                                self.tick(r-1)
                            elif r%RowSize > 0 and sum(self.Array[r-1]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r-1]
                                if selfmag[int(self.RingSize/2)] == adjmag[0]:
                                    self.defrust(0, r-1)
                                    self.tick(r-1)
                            elif r//RowSize > 0 and sum(self.Array[r-RowSize]) < 2:
                                self.nucleate(i, r-RowSize)
                                self.tick(r-RowSize)
                            elif r//RowSize > 0 and sum(self.Array[r-RowSize]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r-RowSize]
                                if selfmag[12] == adjmag[4]:
                                    self.defrust(4, r-RowSize)
                                    self.tick(r-RowSize)
                        else:
                            tempring[i] = 0
                            tempdir[i] = 0
                            if self.T2TMin < self.RingSize/4:
                                tempring[int(self.RingSize/4)] = 1
                                tempdir[int(self.RingSize/4)] += -1
                                if tempdir[int(self.RingSize/4)] == 0:
                                    tempring[int(self.RingSize/4)] = 0
                            else:
                                tempring[int(3*self.RingSize/4)] = 1
                                tempdir[int(3*self.RingSize/4)] += -1
                                if tempdir[int(3*self.RingSize/4)] == 0:
                                    tempring[int(3*self.RingSize/4)] = 0
                            if r%RowSize > 0 and sum(self.Array[r-1]) < 2:
                                self.nucleate(i, r-1)
                                self.tick(r-1)
                            elif r%RowSize > 0 and sum(self.Array[r-1]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r-1]
                                if selfmag[int(self.RingSize/2)] == adjmag[0]:
                                    self.defrust(0, r-1)
                                    self.tick(r-1)
                    else:
                        tempring[i] = ring[i]
                        tempdir[i] = direction[i]                       
                elif i == 3 * RingSize/4:
                    loc = RowSize * (RowSize-1) + (r//RowSize) * RowSize - (RowSize - r%RowSize)
                    if r//RowSize > 0:
                        if junction[loc]==3:
                            DepinChance = 1
                            junction[loc] = 0
                        elif junction[loc]==4:
                            DepinChance = 0
                            junction[loc] = 2
                        elif junction[loc]==1:
                            junction[loc] = 2
                    if DepinChance > x and (self.T2TMin > self.RingSize/2 - 1 or self.T2TMin==0): 
                        tempring[i] = 0
                        tempdir[i] = 0
                        tempring[self.T2TMin] = 1
                        tempdir[self.T2TMin] += -1
                        if tempdir[self.T2TMin] == 0:
                            tempring[self.T2TMin] = 0                           
                        if r//RowSize > 0 and sum(self.Array[r-RowSize]) < 2:
                            self.nucleate(i, r-RowSize)
                            self.tick(r-RowSize)
                        elif r//RowSize > 0 and sum(self.Array[r-RowSize]) == 2:
                            selfmag = self.Magnetisation[r]
                            adjmag = self.Magnetisation[r-RowSize]
                            if selfmag[int(3*self.RingSize/4)] == adjmag[int(self.RingSize/4)]:
                                self.defrust(int(self.RingSize/4), r-RowSize)
                                self.tick(r-RowSize)
                    elif DepinChance > x and self.T2TMin < self.RingSize/2:
                        y = np.random.ranf()
                        FieldComponent = np.sin(Lag) * (np.sqrt((self.Hinput)**2 - ((self.Eccentricity * self.Hinput)**2) * np.sin(locangle)**2))
                        if self.RingSize/4 < self.T2TMin < self.RingSize/2:
                            ex = e0[int(self.RingSize/2)]
                        else:
                            ex = e0[0]
                        DeltaH = ex * (1-(FieldComponent/H_0))**alpha
                        Tau = Tau0 * np.exp(DeltaH/kT)
                        DepinChance = 1 - np.exp(-self.TickTime/Tau)
                        if DepinChance > y and self.RingSize/4 < self.T2TMin < self.RingSize/2:
                            tempring[i] = 0
                            tempdir[i] = 0
                            tempring[self.T2TMin] = 1
                            tempdir[self.T2TMin] += -1
                            if tempdir[self.T2TMin] == 0:
                                tempring[self.T2TMin] = 0
                            loc = r//RowSize * (RowSize-1) + (r%RowSize)-1
                            if junction[loc]==1:
                                junction[loc] = 3
                            if r//RowSize > 0 and sum(self.Array[r-RowSize]) < 2:
                                self.nucleate(i, r-RowSize)
                                self.tick(r-RowSize)
                            elif r//RowSize > 0 and sum(self.Array[r-RowSize]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r-RowSize]
                                if selfmag[int(3*self.RingSize/4)] == adjmag[int(self.RingSize/4)]:
                                    self.defrust(int(self.RingSize/4), r-RowSize)
                                    self.tick(r-RowSize)
                            elif r%RowSize > 0 and sum(self.Array[r-1]) < 2:
                                self.nucleate(i, r-1)
                                self.tick(r-1)
                            elif r%RowSize > 0 and sum(self.Array[r-1]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r-1]
                                if selfmag[int(self.RingSize/2)] == adjmag[0]:
                                    self.defrust(0, r-1)
                                    self.tick(r-1)
                        elif DepinChance > y and 0 < self.T2TMin < self.RingSize/4:
                            tempring[i] = 0
                            tempdir[i] = 0
                            tempring[self.T2TMin] = 1
                            tempdir[self.T2TMin] += -1
                            if tempdir[self.T2TMin] == 0:
                                tempring[self.T2TMin] = 0
                            loc = r//RowSize * (RowSize-1) + r%RowSize
                            if junction[loc]==1:
                                junction[loc] = 3
                            if r//RowSize > 0 and sum(self.Array[r-RowSize]) < 2:
                                self.nucleate(i, r-RowSize)
                                self.tick(r-RowSize)
                            elif r//RowSize > 0 and sum(self.Array[r-RowSize]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r-RowSize]
                                if selfmag[int(3*self.RingSize/4)] == adjmag[int(self.RingSize/4)]:
                                    self.defrust(int(self.RingSize/4), r-RowSize)
                                    self.tick(r-RowSize)
                            elif r%RowSize < RowSize-1 and sum(self.Array[r+1]) < 2: 
                                self.nucleate(i, r+1)
                            elif r%RowSize < RowSize-1 and sum(self.Array[r+1]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r+1]
                                if selfmag[0] == adjmag[int(self.RingSize/2)]:
                                    self.defrust(int(self.RingSize/2), r+1)
                        else:
                            tempring[i] = 0
                            tempdir[i] = 0
                            if self.T2TMin > self.RingSize/4:
                                tempring[int(self.RingSize/2)] = 1
                                tempdir[int(self.RingSize/2)] += -1
                                if tempdir[int(self.RingSize/2)] == 0:
                                    tempring[int(self.RingSize/2)] = 0
                            else:
                                tempring[0] = 1
                                tempdir[0] += -1
                                if tempdir[0] == 0:
                                    tempring[0] = 0
                            if r//RowSize > 0 and sum(self.Array[r-RowSize]) < 2:
                                self.nucleate(i, r-RowSize)
                                self.tick(r-RowSize)
                            elif r//RowSize > 0 and sum(self.Array[r-RowSize]) == 2:
                                selfmag = self.Magnetisation[r]
                                adjmag = self.Magnetisation[r-RowSize]
                                if selfmag[int(3*self.RingSize/4)] == adjmag[int(self.RingSize/4)]:
                                    self.defrust(int(self.RingSize/4), r-RowSize)
                                    self.tick(r-RowSize)
                    else:
                        tempring[i] = ring[i]
                        tempdir[i] = direction[i]
        #Use the information contained in the ring and direction vectors after they
        #have been operated upon to provide information on local magnetisation direction for
        #each ring location
        ring = tempring
        mag = np.zeros(self.RingSize)
        if sum(ring) < 2:
            self.Array[r] = np.zeros(self.RingSize)  
            self.Direction[r] = np.zeros(self.RingSize)
            if sum(self.Magnetisation[r]) > 0:
                for i in range(self.RingSize):
                    mag[i] = 1
            else: 
                for i in range(self.RingSize):
                    mag[i] = -1
        #Use the information contained in the ring and direction vectors after they
        #have been operated upon to provide information on local magnetisation direction for
        #each ring location
        MagDir = 1
        direction = tempdir        
        T2TLoc = 0
        if sum(ring) > 0: 
            self.Direction[r] = direction
            self.Array[r] = ring
            for y in range(self.RingSize):
                if direction[y] == -1:
                    T2TLoc = y
                if abs(ring[i]) == 2:
                    ring[i] = 0
                if sum(direction) != 0:
                    self.Direction[r] = np.zeros(self.RingSize)
            for x in range(self.RingSize):
                if direction[(T2TLoc + x) % self.RingSize] == 0:
                    mag[(T2TLoc+x) % self.RingSize] = MagDir
                elif direction[(T2TLoc + x) % self.RingSize] == 1:
                    MagDir = - 1
        self.Magnetisation[r] = mag  
        mx = []
        my = []
        for i in range(RingSize):
            mx.append(np.sin((16-i) * 2 * np.pi/16) * mag[i])
            my.append(-np.cos((16-i) * 2 * np.pi/16) * mag[i])
        self.Mx[r] = sum(mx)
        self.My[r] = sum(my)
        
        
        

    def imgoutput(self, duration, H_input, TicksPerImg):
        for i in range(duration+1):
            self.time += 1
            #Sweeps Field direction per tick
            self.H2HMin =- (i-4)%16
            self.T2TMin =-(i+4)%16
            Frequency=0.2
            self.TickTime = 1/(Frequency*self.RingSize)
            self.Hinput = H_input
            RowSize = self.RowSize
            RingSize = self.RingSize
            RingNum = self.RingNum
            K = self.K
            Mx = self.Mx
            My = self.My
            MaxM = self.MaxM
            Array = self.Array
            Direction = self.Direction
            Magnetisation = self.Magnetisation
            #Calls upon tick function to output how the array responds to a sweep in
            #magnetic field.
            DWcount=0
            for r in range(self.RingNum):
                self.tick(r)
            #Counts total number of DWs present after the tick.
            for r in range(self.RingNum):
                DWcount+=sum(Array[r])
            #Sets the blank window for the graphical output to be drawn onto
            if i%(TicksPerImg) == 0:
                win = gp.GraphWin("My Window", 1000, 1000)
                win.setBackground('white')
                Count=gp.Text(gp.Point(500,500), 'Domain Wall Count: '+str(DWcount))
                Count.draw(win)
                Timer=gp.Text(gp.Point(500,750), 'Time: '+str(self.time))
                Timer.draw(win)
                Magx=gp.Text(gp.Point(500/RowSize,500/RowSize -25), 'Magnetisation(x): '+str(round(sum((Mx)/MaxM),2)))
                Magx.draw(win)
                Magy=gp.Text(gp.Point(500/RowSize,500/RowSize +25), 'Magnetisation(y): '+str(round(sum((My)/MaxM),2)))
                Magy.draw(win)                       
                for j in range(RingNum):
                    #Erases data from previous entry
                    # Defines the X position of the centre each ring
                    X=(j%RowSize)*(1000/RowSize)+(500/RowSize)
                    # Defines the Y position of the centre each ring
                    Y=(j//RowSize)*(1000/RowSize)+(500/RowSize)       
                    #Draw the geometry for each ring
                    OD = gp.Circle(gp.Point(X,Y),500/RowSize)
                    OD.draw(win)
                    ID = gp.Circle(gp.Point(X,Y),500/RowSize-40)
                    ID.draw(win)
                    # Draws the minimum energy location of '+' and '-' DWs
                    minplus=gp.Image(gp.Point(X+((500/RowSize)-20)*np.cos((-(i-4)%16)*np.pi/K),Y+((500/RowSize)-20)*+np.sin((-(i-4)%16)*np.pi/K)), "MinPlus.gif")
                    minplus.draw(win)
                    minmin=gp.Image(gp.Point(X+((500/RowSize)-20)*np.cos((-(i+4)%16)*np.pi/K),Y+((500/RowSize)-20)*+np.sin((-(i+4)%16)*np.pi/K)), "MinMinus.gif")
                    minmin.draw(win)
                    #Provide real time information as to how many ticks have passed and how many
                    #DWs are present in the array at each instance.
                    # Plots each ring from within the array
                    Ring=Array[j]
                    Dir=Direction[j]
                    Mag=Magnetisation[j]
                    for k in range(RingSize):
                        if Dir[k] == 1 and Ring[k] == 1:
                            plus = gp.Image(gp.Point(X+((500/RowSize)-20)*np.cos(k*np.pi/K),Y+((500/RowSize)-20)*+np.sin(k*np.pi/K)), "Plus.gif")
                            plus.draw(win)
                        elif Dir[k] == -1 and Ring[k]==1:
                            minus = gp.Image(gp.Point(X+((500/RowSize)-20)*np.cos(k*np.pi/K),Y+((500/self.RowSize)-20)*+np.sin(k*np.pi/K)), "Minus.gif")
                            minus.draw(win)
                        if Ring[k] == 0 and Mag[k] == 1:
                            if k==0:
                                mg=gp.Image(gp.Point(X+((500/RowSize)-20)*np.cos(k*np.pi/K),Y+((500/RowSize)-20)*+np.sin(k*np.pi/K)), "DownR.gif")
                                mg.draw(win)
                            elif k==2:
                                mg=gp.Image(gp.Point(X+((500/RowSize)-20)*np.cos(k*np.pi/K),Y+((500/RowSize)-20)*+np.sin(k*np.pi/K)), "DLR.gif")
                                mg.draw(win)
                            elif k==4:
                                mg=gp.Image(gp.Point(X+((500/RowSize)-20)*np.cos(k*np.pi/K),Y+((500/RowSize)-20)*+np.sin(k*np.pi/K)), "LeftR.gif")
                                mg.draw(win)
                            elif k==6:
                                mg=gp.Image(gp.Point(X+((500/RowSize)-20)*np.cos(k*np.pi/K),Y+((500/RowSize)-20)*+np.sin(k*np.pi/K)), "ULR.gif")
                                mg.draw(win)
                            elif k==8:
                                mg=gp.Image(gp.Point(X+((500/RowSize)-20)*np.cos(k*np.pi/K),Y+((500/RowSize)-20)*+np.sin(k*np.pi/K)), "UpR.gif")
                                mg.draw(win)
                            elif k==10:
                                mg=gp.Image(gp.Point(X+((500/RowSize)-20)*np.cos(k*np.pi/K),Y+((500/RowSize)-20)*+np.sin(k*np.pi/K)), "URR.gif")
                                mg.draw(win)
                            elif k==12:
                                mg=gp.Image(gp.Point(X+((500/RowSize)-20)*np.cos(k*np.pi/K),Y+((500/RowSize)-20)*+np.sin(k*np.pi/K)), "RightR.gif")
                                mg.draw(win)
                            elif k==14:
                                mg=gp.Image(gp.Point(X+((500/RowSize)-20)*np.cos(k*np.pi/K),Y+((500/RowSize)-20)*+np.sin(k*np.pi/K)), "DRR.gif")
                                mg.draw(win)
                        elif Ring[k] == 0 and Mag[k] == -1:
                            if k==0:
                                mg=gp.Image(gp.Point(X+((500/RowSize)-20)*np.cos(k*np.pi/K),Y+((500/RowSize)-20)*+np.sin(k*np.pi/K)), "UpB.gif")
                                mg.draw(win)
                            elif k==2:
                                mg=gp.Image(gp.Point(X+((500/RowSize)-20)*np.cos(k*np.pi/K),Y+((500/RowSize)-20)*+np.sin(k*np.pi/K)), "URB.gif")
                                mg.draw(win)
                            elif k==4:
                                mg=gp.Image(gp.Point(X+((500/RowSize)-20)*np.cos(k*np.pi/K),Y+((500/RowSize)-20)*+np.sin(k*np.pi/K)), "RightB.gif")
                                mg.draw(win)
                            elif k==6:
                                mg=gp.Image(gp.Point(X+((500/RowSize)-20)*np.cos(k*np.pi/K),Y+((500/RowSize)-20)*+np.sin(k*np.pi/K)), "DRB.gif")
                                mg.draw(win)
                            elif k==8:
                                mg=gp.Image(gp.Point(X+((500/RowSize)-20)*np.cos(k*np.pi/K),Y+((500/RowSize)-20)*+np.sin(k*np.pi/K)), "DownB.gif")
                                mg.draw(win)
                            elif k==10:
                                mg=gp.Image(gp.Point(X+((500/RowSize)-20)*np.cos(k*np.pi/K),Y+((500/RowSize)-20)*+np.sin(k*np.pi/K)), "DLB.gif")
                                mg.draw(win)
                            elif k==12:
                                mg=gp.Image(gp.Point(X+((500/RowSize)-20)*np.cos(k*np.pi/K),Y+((500/RowSize)-20)*+np.sin(k*np.pi/K)), "LeftB.gif")
                                mg.draw(win)
                            elif k==14:
                                mg=gp.Image(gp.Point(X+((500/RowSize)-20)*np.cos(k*np.pi/K),Y+((500/RowSize)-20)*+np.sin(k*np.pi/K)), "ULB.gif")
                                mg.draw(win)
                #Saves graphical output to a temporary output file
                win.postscript(file="output.eps")
                with open('output.eps', 'r') as input:
                    with open('output%i.eps' %i, 'w') as output:
                        for line in input:
                            output.write(line)
                win.close()
        with open('ArrayState.pkl', 'wb') as f:
            pickle.dump([Array, self.E0, self.Magnetisation, Direction, self.H_switching, self.junction, RingSize, RingNum, self.BaseE0, self.PinCoupling, MaxM, Mx, My, self.RowSize, K, self.alpha, self.kT, self.Tau0, self.time], f)
                 
        
    
        
    def TimeResolvedFieldChange(self, H1, H2, duration=1600):
        timeoutput = np.zeros((2,duration))
        timeoutput1 = np.zeros(duration)
        timeoutput2 = np.zeros(duration)
        for x in range(int(duration/2)):
            self.H2HMin=-(x-4)%16
            self.T2TMin=-(x+4)%16
            self.Hinput = H1
            for r in range(self.RingNum):
                self.tick(r)
            DWC = 0
            My = 0
            for r in range(self.RingNum):
                DWC += sum(self.Array[r])
                My += self.My[r]
            timeoutput1[x] = My/self.MaxM
            timeoutput2[x] = 0.5*DWC/self.RingNum
        for x in range(int(duration/2)):
            self.H2HMin=-(x-4)%16
            self.T2TMin=-(x+4)%16
            self.Hinput = H2
            for r in range(self.RingNum):
                self.tick(r)
            DWC = 0
            My = 0
            for r in range(self.RingNum):
                DWC += sum(self.Array[r])
                My += self.My[r]
            timeoutput1[x+int(duration/2)] = My/self.MaxM
            timeoutput2[x+int(duration/2)] = 0.5*DWC/self.RingNum
        timeoutput[0] = timeoutput1
        timeoutput[1] = timeoutput2
        np.savetxt('Timeplot, Temperature = '+str(np.round(self.kT/1.38e-23))+' Array Size='+str(self.RingNum)+', H1='+str(H1)+', H2='+str(H2)+'.csv', np.transpose(timeoutput), delimiter=',')

        
    def FieldRangeSweep(self, Field, NoR):
        duration = (NoR+3) * 16 + 1
        output1 = []
        output2 = []
        for H in Field:
            for i in range(duration):
                if i+1//48 == 0:
                    self.Hinput = 180
                else:
                    self.Hinput = H
                #Sweeps Field direction per tick
                self.H2HMin=-(i-4)%16
                self.T2TMin=-(i+4)%16
                #Calls upon tick function to output how the array responds to a sweep in
                #magnetic field.
                for r in range(self.RingNum):
                    self.tick(r)
            endmag=0
            endpop=0
            for r in range(self.RingNum):
                endmag += self.My[r]
                endpop += sum(self.Array[r])
            normendmag = endmag/self.MaxM
            normendpop = endpop/(self.RingNum * 2)
            output1.append(normendmag)
            output2.append(normendpop)
        return output1
        
    def bigimgoutput(self, duration, H_input, qperimg):
        for i in range(duration+1):
            self.time += 1
            #Sweeps Field direction per tick
            self.H2HMin =- (i-4)%16
            self.T2TMin =-(i+4)%16
            Frequency=0.2
            self.TickTime = 1/(Frequency*self.RingSize)
            self.Hinput = H_input
            RowSize = self.RowSize
            RingSize = self.RingSize
            RingNum = self.RingNum
            K = self.K
            Mx = self.Mx
            My = self.My
            MaxM = self.MaxM
            Array = self.Array
            Direction = self.Direction
            Magnetisation = self.Magnetisation
            width = 32 * RowSize
            #Calls upon tick function to output how the array responds to a sweep in
            #magnetic field.
            DWcount=0
            for r in range(self.RingNum):
                self.tick(r)
            #Counts total number of DWs present after the tick.
            for r in range(self.RingNum):
                DWcount+=sum(Array[r])
            #Sets the blank window for the graphical output to be drawn onto
            if i%(4*qperimg) == 0 and i > 0:
                win = gp.GraphWin("My Window", width, width)
                win.setBackground('white')                     
                for j in range(RingNum):
                    #Erases data from previous entry
                    # Defines the X position of the centre each ring
                    X=(j%RowSize)*(width/RowSize)+(width/(2*RowSize))
                    # Defines the Y position of the centre each ring
                    Y=(j//RowSize)*(width/RowSize)+(width/(2*RowSize))       
                    # Plots each ring from within the array
                    Ring = Array[j]
                    Dir=Direction[j]
                    Mag=Magnetisation[j]
                    if sum(Ring) < 2:
                        if sum(Mag) > 0:
                            RV = gp.Image(gp.Point(X, Y), "RV.png")
                            RV.draw(win)
                        elif sum(Mag) < 0:
                            BV = gp.Image(gp.Point(X, Y), "BV.png")
                            BV.draw(win)
                    elif Dir[0] == 1 and Dir[8] == -1:
                        ROS = gp.Image(gp.Point(X, Y), "ROS.png")
                        ROS.draw(win)
                    elif Dir[0] == -1 and Dir[8] == 1:
                        RON = gp.Image(gp.Point(X, Y), "RON.png")
                        RON.draw(win)
                    elif Dir[4] == 1 and Dir[12] == -1:
                        ROW = gp.Image(gp.Point(X, Y), "ROW.png")
                        ROW.draw(win)
                    elif Dir[4] == -1 and Dir[12] == 1:
                        ROE = gp.Image(gp.Point(X, Y), "ROE.png")
                        ROE.draw(win)
                    elif Dir[0] == 1 and Dir[4] == -1:
                        BTSE = gp.Image(gp.Point(X, Y), "BTSE.png")
                        BTSE.draw(win)
                    elif Dir[0] == -1 and Dir[4] == 1:
                        RTSE = gp.Image(gp.Point(X, Y), "RTSE.png")
                        RTSE.draw(win)
                    elif Dir[4] == 1 and Dir[8] == -1:
                        BTSW = gp.Image(gp.Point(X, Y), "BTSW.png")
                        BTSW.draw(win)
                    elif Dir[4] == -1 and Dir[8] == 1:
                        RTSW = gp.Image(gp.Point(X, Y), "RTSW.png")
                        RTSW.draw(win)
                    elif Dir[8] == 1 and Dir[12] == -1:
                        BTNW = gp.Image(gp.Point(X, Y), "BTNW.png")
                        BTNW.draw(win)
                    elif Dir[8] == -1 and Dir[12] == 1:
                        RTNW = gp.Image(gp.Point(X, Y), "RTNW.png")
                        RTNW.draw(win)
                    elif Dir[12] == 1 and Dir[0] == -1:
                        BTNE = gp.Image(gp.Point(X, Y), "BTNE.png")
                        BTNE.draw(win)
                    elif Dir[12] == -1 and Dir[0] == 1:
                        RTNE = gp.Image(gp.Point(X, Y), "RTNE.png")
                        RTNE.draw(win)
                win.postscript(file="output.eps")
                with open('output.eps', 'r') as input:
                    with open('output%i.eps' %i, 'w') as output:
                        for line in input:
                            output.write(line)
                win.close()
        with open('ArrayState.pkl', 'wb') as f:
            pickle.dump([Array, self.E0, self.Magnetisation, Direction, self.H_switching, self.junction, RingSize, RingNum, self.BaseE0, self.PinCoupling, MaxM, Mx, My, self.RowSize, K, self.alpha, self.kT, self.Tau0, self.time], f)
    
    def SignalTransform(self, signal, Centre, Range, tpi, tpo):
            nodeoutput=np.zeros((4, len(signal)*int(tpi/tpo)))
            duration=int((len(signal))*tpi)
            for x in range(160):        
                #initialise and let array settle to first datapoint
                self.H2HMin=-(x-4)%16
                self.T2TMin=-(x+4)%16
                self.Hinput = Centre+Range*float(signal[0])
                for r in range(self.RingNum):
                    self.tick(r)
            # apply modulated field according to signal input
            for i in range(duration):
                self.Hinput=Centre+Range*float(signal[i//tpi])
                self.H2HMin=-(i-4)%16
                self.T2TMin=-(i+4)%16
                for r in range(self.RingNum):
                    self.tick(r)
                #Calls upon tick function to output how the array responds to a sweep in
                #magnetic field.
                if i % tpo == 0:
                    DWC=0
                    MX=0
                    MY=0
                    for x in range(self.RingNum):
                        DWC += sum(self.Array[x])
                        MX += self.Mx[x]
                        MY += self.My[x]
                    Mag = np.sqrt(MX**2 + MY**2)
                    nodeoutput[0, i//tpo] = DWC/(self.RingNum*2)
                    nodeoutput[1, i//tpo] = Mag / abs(self.MaxM)
                    nodeoutput[2, i//tpo] = MX / abs(self.MaxM)
                    nodeoutput[3, i//tpo] = MY / abs(self.MaxM)
            np.savetxt('* Output Centre '+str(Centre)+' Range '+str(Range)+'.csv', nodeoutput, delimiter=',')        
    
    def DelayedMagFeedback(self, Signal, Centre, Range, tpi, tpo, Delay, DelayLineMult):
            DWCoutput = np.zeros(((int(len(Signal)))))
            Magoutput = np.zeros(((int(len(Signal)))))
            Mxoutput = np.zeros(((int(len(Signal)))))
            Myoutput = np.zeros(((int(len(Signal)))))
            duration = int(len(Signal)*tpi)
            for x in range(160):        
                #Sweeps Field direction per tick
                self.H2HMin=-(x-4)%16
                self.T2TMin=-(x+4)%16
                self.Hinput = Centre+Range*float(Signal[0])
                for r in range(self.RingNum):
                    self.tick(r)
            for i in range(duration):
                if i == 0:
                    for x in range(160):        
                        self.H2HMin=-(x-4)%16
                        self.T2TMin=-(x+4)%16
                        self.Hinput = Centre+Range*float(Signal[i//tpi])
                if i < Delay:
                    self.Hinput= Centre + Range * float(Signal[i//(tpi)]) 
                else: 
                    self.Hinput = Centre + Range * ((float(Signal[i//(tpi)]) + (float(Magoutput[(i-Delay)//tpi])) * DelayLineMult))
                #Sweeps Field direction per tick
                self.H2HMin=-(i-4)%16
                self.T2TMin=-(i+4)%16
                #Calls upon tick function to output how the array responds to a sweep in
                #magnetic field.
                for r in range(self.RingNum):
                    self.tick(r)                
                if i % tpo == 0:
                    DWC=0
                    MX=0
                    MY=0
                    for x in range(self.RingNum):
                        DWC += sum(self.Array[x])
                        MX += self.Mx[x]
                        MY += self.My[x]
                    Mag = np.sqrt(MX**2 + MY**2)
                    DWCoutput[i//tpo] = DWC/(self.RingNum*2)
                    Magoutput[i//tpo] = Mag / abs(self.MaxM)
                    Myoutput[i//tpo] = MX / abs(self.MaxM)
                    Mxoutput[i//tpo] = MY / abs(self.MaxM)
            MCoutput = np.zeros((4, len(DWCoutput)))
            MCoutput[0] = DWCoutput
            MCoutput[1] = Magoutput
            MCoutput[2] = Myoutput
            MCoutput[3] = Mxoutput
            np.savetxt('* Output '+str(Centre)+' '+str(Range)+' '+str(tpi)+' '+str(Delay)+' '+str(np.round(DelayLineMult, 3))+'.csv', MCoutput, delimiter=',')


    def StateCount(self, duration, H_input, qpercount):
        outdata = np.zeros((int(duration/(4*qpercount)), 4))
        for i in range(duration):
            self.time += 1
            #Sweeps Field direction per tick
            self.H2HMin =- (i-4)%16
            self.T2TMin =-(i+4)%16
            Frequency=0.2
            self.TickTime = 1/(Frequency*self.RingSize)
            self.Hinput = H_input
            RowSize = self.RowSize
            RingSize = self.RingSize
            RingNum = self.RingNum
            Array = self.Array
            Direction = self.Direction
            Magnetisation = self.Magnetisation
            width = 32 * RowSize
            #Calls upon tick function to output how the array responds to a sweep in
            #magnetic field.
            DWcount=0
            for r in range(self.RingNum):
                self.tick(r)
            #Counts total number of DWs present after the tick.
            for r in range(self.RingNum):
                DWcount+=sum(Array[r])
            #Sets the blank window for the graphical output to be drawn onto
            if i%(4*qpercount) == 0:          
                vortexcount = 0
                tqcount = 0
                onioncount = 0
                for j in range(RingNum):
                    # Plots each ring from within the array
                    Ring = Array[j]
                    Dir=Direction[j]
                    Mag=Magnetisation[j]
                    if sum(Ring) < 2:
                        if sum(Mag) > 0:
                            vortexcount += 1
                    elif Dir[0] == 1 and Dir[8] == -1:
                        onioncount += 1
                    elif Dir[0] == -1 and Dir[8] == 1:
                        onioncount += 1
                    elif Dir[4] == 1 and Dir[12] == -1:
                        onioncount += 1
                    elif Dir[4] == -1 and Dir[12] == 1:
                        onioncount += 1
                    elif Dir[0] == 1 and Dir[4] == -1:
                        tqcount +=1
                    elif Dir[0] == -1 and Dir[4] == 1:
                        tqcount +=1
                    elif Dir[4] == 1 and Dir[8] == -1:
                        tqcount +=1
                    elif Dir[4] == -1 and Dir[8] == 1:
                        tqcount +=1
                    elif Dir[8] == 1 and Dir[12] == -1:
                        tqcount +=1
                    elif Dir[8] == -1 and Dir[12] == 1:
                        tqcount +=1
                    elif Dir[12] == 1 and Dir[0] == -1:
                        tqcount += 1
                    elif Dir[12] == -1 and Dir[0] == 1:
                        tqcount += 1
            outdata[i//(4*qpercount)] = [vortexcount, onioncount, tqcount, i//4]
        np.savetxt('State Data, Happ '+str(H_input)+' H0 '+str(self.H0)+' E0 '+str(self.BaseE0)+'.csv', outdata, delimiter=',')
                

####################################################################################################################################






#####################################################################################################################################

# Enter Commands Here, e.g.: #
H=145
E=1.6e-19
sim = RingSim(20**2, BaseE0=E, H0=H, kT = 298*1.38e-23, FieldEccentricity=0)
Field = np.linspace(20, 50, num=13)
MagOutput = sim.FieldRangeSweep(Field, 10)
plt.figure()
plt.plot(Field, MagOutput)
plt.xlabel('Applied Field')
plt.ylabel('Net Magnetisation')
filename = ('H0 = '+str(H)+', E0 = '+str(E))
plt.title(filename)
plt.show()
np.savetxt(filename+'.csv', MagOutput, delimiter=',')
        

            
    


